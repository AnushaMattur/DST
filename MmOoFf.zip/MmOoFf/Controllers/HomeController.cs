﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MOF.Models;

namespace MOF.Controllers
{
    public class HomeController : Controller
    {
        private CupCakeEntities db = new CupCakeEntities();
        private AddingCupCakeEntities dba = new AddingCupCakeEntities();

        // GET: ViewingDetails

        public ActionResult Index()
        {
            CupCakeEntities refcupcakeentities = new CupCakeEntities();
            return View(refcupcakeentities.RegisterUsers.ToList());
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(RegisterUser refregisteruser)
        {
            ViewBag.Message = "Your registration page.";

            if(ModelState.IsValid)
            {
               db.RegisterUsers.Add(refregisteruser);
               db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(refregisteruser);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(RegisterUser refregisteruser)
        {          
                    var obj = db.RegisterUsers.Where(a => a.UserName.Equals(refregisteruser.UserName) && a.Password.Equals(refregisteruser.Password)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserID"] = obj.UserId.ToString();
                        Session["UserName"] = obj.UserName.ToString();
                        var admin = obj.IsAdmin;
                        if(admin==0)
                        {
                            return RedirectToAction("AdminView", "AddingDetails");
                        }
                        else
                        {
                            return RedirectToAction("UserDashBoard","Home");
                        }
                        
                    }
                    return View(refregisteruser);
        }


        public ActionResult UserDashBoard()
        {
            if (Session["UserID"] != null)
            {
                //< td > Welcome : @Session["UserName"] !!</ td >
                //return View();
                return View(dba.AddingDetails.ToList());
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        public ActionResult GetCupCakebyName(string searchstr)
        {
            if (searchstr != null)
            {
                var obj = dba.AddingDetails
                          .Where(x => x.Name.Contains(searchstr))
                          .AsEnumerable()
                          .Select(x => new AddingDetail
                          {
                              Name = x.Name,
                              Cost = x.Cost,
                              ImageUrl = x.ImageUrl
                          });
                return PartialView("Cupcakelist", obj.ToList());
            }
            return View();
        }

        public PartialViewResult Cupcakelist()
        {
            var obj = dba.AddingDetails.ToList();
            return PartialView("Cupcakelist", obj);
        }
    }
}