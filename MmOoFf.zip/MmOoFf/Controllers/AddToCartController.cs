﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Web;
using System.Web.Mvc;
using MOF.Models;

namespace MOF.Controllers
{
    public class AddToCartController : Controller
    {
        // GET: AddToCart
        //public ActionResult Index()
        //{
        //    return View();
        //}

        //DataTable dt;
        //MobiledetailDAL _mdal = new MobiledetailDAL();
        AddingCupCakeEntities db = new AddingCupCakeEntities();
        // GET: AddToCart  
        public ActionResult Add(AddingDetail ad)
        {

            if (Session["cart"] == null)
            {
                List<AddingDetail> li = new List<AddingDetail>();

                li.Add(ad);
                Session["cart"] = li;
                ViewBag.cart = li.Count();

                Session["count"] = 1;
            }
            else
            {
                List<AddingDetail> li = (List<AddingDetail>)Session["cart"];
                li.Add(ad);
                Session["cart"] = li;
                ViewBag.cart = li.Count();
                Session["count"] = Convert.ToInt32(Session["count"]) + 1;
            }
            return RedirectToAction("UserDashBoard", "Home");
        }

        public ActionResult Myorder()
        {
            return View((List<AddingDetail>)Session["cart"]);
        }
    }
}