﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Adem
{
    public partial class Search_Employee : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=BGLRM9100213\MSSQLSERVER2014;Initial Catalog=AdminemployeeDB;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                datafill();
            }
        }
        void datafill()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from Employee_Member where Emp_Id=@Emp_Id";
            cmd.Parameters.AddWithValue("@Emp_Id", Emp_Id.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            da.Fill(ds);
            FV_Employee.DataSource = ds;
            FV_Employee.DataBind();
            //FV_Employee.DataSource = ds;
            //FV_Employee.DataBind();
        }

        protected void search_Click(object sender, EventArgs e)
        {
            datafill();
        }
    }
}