﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Adem
{
    public partial class LoginPage : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=BGLRM9100213\MSSQLSERVER2014;Initial Catalog=AdminemployeeDB;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox2.Text = "";
            TextBox3.Text = "";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Empusername,Emppassword from Adminemployee where Empusername = @Username and Emppassword = @Password";
            cmd.Parameters.AddWithValue("@Username", TextBox2.Text);
            cmd.Parameters.AddWithValue("@Password", TextBox3.Text);
            Session["Empusername"] = TextBox2.Text;
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();

            if (sdr != null && sdr.HasRows)
            {
                string Emprole = GetUserRole();
                Response.Write(Emprole);
                // Label2.Text += Emprole;
                if (Emprole.Contains("Admin")==true)
                {
                    Response.Redirect("Admin.aspx");
                }
                else if (Emprole.Contains("Employee")==true)
                {
                    Response.Redirect("Employee.aspx");
                }
                else
                {
                    Label2.Text += "Sorry";
                }
            }
            else
            {
                Label2.Attributes["style"] = "color:red";
                Label2.Text = "Sorry username and password doesn't match!!";
            }
            con.Close();         
        }

        public string GetUserRole()
        {
            SqlConnection con1 = new SqlConnection(@"Data Source=BGLRM9100213\MSSQLSERVER2014;Initial Catalog=AdminemployeeDB;Integrated Security=True");
            string Role;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Emprole from Adminemployee where Empusername = @Username and Emppassword = @Password";
            cmd.Parameters.AddWithValue("@Username", TextBox2.Text);
            cmd.Parameters.AddWithValue("@Password", TextBox3.Text);
            Session["Empusername"] = TextBox2.Text;
            con1.Open();
            Role = Convert.ToString(cmd.ExecuteScalar());
            con1.Close();
            //Label2.Text = Role;
            return Role;
        }
    }
}