﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Adem
{
    

    public partial class Edit_Employee : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=BGLRM9100213\MSSQLSERVER2014;Initial Catalog=AdminemployeeDB;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                datafill();
            }
        }

        //protected void btnAdd_Click(object sender, EventArgs e)
        //{

        //}
        void datafill()
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from Employee_Member";

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            da.Fill(ds);
            GV_Emplyee.DataSource = ds;
            GV_Emplyee.DataBind();
        }
        void clear_controls()
        {
            Emp_Id.Text = " ";
            Emp_Name.Text = " ";
            Designation.Text = " ";
            Location.Text = " ";
            Project_Name.Text = " ";
            Port_No.Text = " ";
            Email.Text = " ";
            Extension.Text = " ";
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Employee_Member values(@Emp_Id,@Emp_Name,@Designation,@Location,@Project_Name,@Port_No,@Email,@Extension)";
            cmd.Parameters.AddWithValue("@Emp_Id", Emp_Id.Text);
            cmd.Parameters.AddWithValue("@Emp_Name", Emp_Name.Text);
            cmd.Parameters.AddWithValue("@Designation", Designation.Text);
            cmd.Parameters.AddWithValue("@Location", Location.Text);
            cmd.Parameters.AddWithValue("@Project_Name", Project_Name.Text);
            cmd.Parameters.AddWithValue("@Port_No", Port_No.Text);
            cmd.Parameters.AddWithValue("@Email", Email.Text);
            cmd.Parameters.AddWithValue("@Extension", Extension.Text);

            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            datafill();
            lablmsg.Text = "data inserted";
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Employee_Member Set Designation=@Designation,Project_Name=@Project_Name where Emp_Id=@Emp_Id";
            cmd.Parameters.AddWithValue("@Emp_Id", Emp_Id.Text);
            cmd.Parameters.AddWithValue("@Designation", Designation.Text);
            cmd.Parameters.AddWithValue("@Project_Name", Project_Name.Text);
            cmd.Connection = con;
            con.Open();
            if (cmd.ExecuteNonQuery() == 0)
            {
                lablmsg.Text = "data cant be updated";
            }
            else
            {
                lablmsg.Text = "data updated";
            }
            datafill();
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            con.Open();
            SqlParameter Id = new SqlParameter("@Emp_Id", SqlDbType.Int);
            cmd.Parameters.Add(Id);
            Id.Value = Convert.ToInt32(Emp_Id.Text);
            cmd.Connection = con;


            cmd.CommandText = "delete from Employee_Member where Emp_Id=@Emp_Id";
            if (
                cmd.ExecuteNonQuery() == 0)
            {
                lablmsg.Text = "data doestnt exist";
            }
            else
            {
                lablmsg.Text = "data deleted";
            }
            datafill();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            clear_controls();
        }
    }
}
