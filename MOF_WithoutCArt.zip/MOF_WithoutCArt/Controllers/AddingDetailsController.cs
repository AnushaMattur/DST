﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MOF.Models;

namespace MOF.Controllers
{
    public class AddingDetailsController : Controller
    {
        private AddingCupCakeEntities db = new AddingCupCakeEntities();

        // GET: AddingDetails
        public ActionResult Index()
        {
            return View(db.AddingDetails.ToList());
        }

        // GET: AddingDetails/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AddingDetail addingDetail = db.AddingDetails.Find(id);
            if (addingDetail == null)
            {
                return HttpNotFound();
            }
            return View(addingDetail);
        }

        // GET: AddingDetails/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AddingDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CCID,Name,Cost,ImageUrl")] AddingDetail addingDetail)
        {
            if (ModelState.IsValid)
            {
                db.AddingDetails.Add(addingDetail);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(addingDetail);
        }

        // GET: AddingDetails/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AddingDetail addingDetail = db.AddingDetails.Find(id);
            if (addingDetail == null)
            {
                return HttpNotFound();
            }
            return View(addingDetail);
        }

        // POST: AddingDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CCID,Name,Cost,ImageUrl")] AddingDetail addingDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(addingDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(addingDetail);
        }

        // GET: AddingDetails/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AddingDetail addingDetail = db.AddingDetails.Find(id);
            if (addingDetail == null)
            {
                return HttpNotFound();
            }
            return View(addingDetail);
        }

        // POST: AddingDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            AddingDetail addingDetail = db.AddingDetails.Find(id);
            db.AddingDetails.Remove(addingDetail);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult AdminView()
        {
            return View();
        }
    }
}
